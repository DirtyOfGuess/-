public class Driver {
    public static void main(String[] args) {
        //定义一个双向链表类
        MyLinkedList<Integer> myLinkedList = new MyLinkedList<>();

        //添加元素
        myLinkedList.add(3);
        myLinkedList.add(5);
        myLinkedList.add(6);
        myLinkedList.add(7);

        //插入元素
        myLinkedList.add(1,4);

        //遍历集合
        System.out.print("最初的集合: ");
        myLinkedList.ergodic();

        //删除元素并对错误抛出异常
        try {
            myLinkedList.remove(1);
            System.out.print("删除元素后的集合: ");
            myLinkedList.ergodic();
        }
        catch (IndexOutOfBoundsException e){
            System.out.println("删除失败，删除了一个不存在的元素");
        }
        catch (Exception e){
            e.printStackTrace();
        }

        //查找集合元素
        try {
            System.out.print("查找集合的第一个元素为: ");
            System.out.println(myLinkedList.get(0));
        }
        catch (IndexOutOfBoundsException e){
            System.out.println("查找失败，查找了一个不存在的元素");
        }
        catch (Exception e){
            e.printStackTrace();
        }

        //翻转集合
        System.out.print("翻转后的集合: ");
        System.out.println(myLinkedList.overturn());

    }
}
