import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class MyLinkedList<E> {
    private LinkedList<E> list = new LinkedList<>();

    //插入元素
    public void add(E e){
        list.add(e);
    }
    public void add(int i,E e){
        list.add(i, e);
    }

    //删除元素
    public void remove(int i)throws IndexOutOfBoundsException{
        list.remove(i);
    }
    public void remove(E e)throws IndexOutOfBoundsException{

        list.remove(e);
    }

    //查找元素
    public E get(int i)throws IndexOutOfBoundsException{
        return list.get(i);
    }

    //遍历集合
    public void ergodic(){
        System.out.println(list);
    }

    //翻转链表
    public LinkedList<E> overturn() {
        List<E> list1 = new ArrayList<>();
        list1.addAll(list);

        for (int i = 0,j = list.size()-1; i < list.size(); i++,j--) {
            list.set(i,list1.get(j));
        }
        return list;
    }


}
