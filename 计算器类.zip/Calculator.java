import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

public class Calculator {

    /**
     * 将式子进行运算（无括号）
     * @param expression
     * @return
     */
    public long Calculate(String expression) throws ExpressionException, ResultException{
        //变量初始化
        String compactExpression = "";
        List<String> list = new ArrayList<>();
        long firstNum,secondNum,resultNum;

        //将式子去掉其余字符
        for(int i=0;i < expression.length();i++) {
            if(expression.charAt(i) == '*'||expression.charAt(i) == '/'||expression.charAt(i) == '+'
                    ||expression.charAt(i) == '-'||expression.charAt(i) == '0'||expression.charAt(i) == '1'
                    ||expression.charAt(i) == '2'||expression.charAt(i) == '3'||expression.charAt(i) == '4'
                    ||expression.charAt(i) == '5'||expression.charAt(i) == '6'||expression.charAt(i) == '7'
                    ||expression.charAt(8) == '+'||expression.charAt(i) == '9'){
                compactExpression += String.valueOf(expression.charAt(i));
            }
        }
        System.out.println(compactExpression);

        //检测表达式是否含有堆叠的运算符
        expressionCheck(compactExpression);

        //分段存入集合
        StringTokenizer Tokenizer = new StringTokenizer(compactExpression,"+-*/",true);
        while(Tokenizer.hasMoreElements()){
            list.add(Tokenizer.nextToken());
        }

            //先运算乘除法
            for (int i = 0; i < list.size(); i++) {
                if (list.get(i).equals("*")) {
                    //将数据提前储存
                    firstNum = Long.parseLong(list.get(i - 1));
                    secondNum = Long.parseLong(list.get(i + 1));
                    resultNum = firstNum * secondNum;

                    if (!(resultNum == firstNum * secondNum)){
                        throw new ResultException("计算结果溢出");
                    }

                    //删除参与运算的三个字符
                    list.remove(i - 1);
                    list.remove(i - 1);
                    list.remove(i - 1);

                    //进行运算并添加回去
                    list.add(i - 1, String.valueOf(resultNum));
                    i--;//指针回正
                } else if (list.get(i).equals("/")) {
                    firstNum = Long.parseLong(list.get(i - 1));
                    secondNum = Long.parseLong(list.get(i + 1));
                    resultNum = firstNum / secondNum;

                    list.remove(i - 1);
                    list.remove(i - 1);
                    list.remove(i - 1);
                    list.add(i - 1, String.valueOf(resultNum));
                    i--;

                }
            }
            System.out.print("乘除后的式子: ");
            ergodic(list);

            //再运算加减法
            for (int i = 0; i < list.size(); i++) {
                if (list.get(i).equals("+")) {
                    firstNum = Integer.parseInt(list.get(i - 1));
                    secondNum = Integer.parseInt(list.get(i + 1));
                    resultNum = firstNum + secondNum;

                    //判断计算结果溢出
                    if (resultNum<firstNum||resultNum<secondNum){
                        throw new ResultException("计算结果溢出");
                    }

                    list.remove(i - 1);
                    list.remove(i - 1);
                    list.remove(i - 1);
                    list.add(i - 1, String.valueOf(resultNum));
                    i--;

                } else if (list.get(i).equals("-")) {
                    firstNum = Integer.parseInt(list.get(i - 1));
                    secondNum = Integer.parseInt(list.get(i + 1));
                    resultNum = firstNum - secondNum;

                    //判断计算结果溢出
                    if (!(secondNum+resultNum == firstNum)){
                        throw new ResultException("计算结果溢出");
                    }

                    list.remove(i - 1);
                    list.remove(i - 1);
                    list.remove(i - 1);
                    list.add(i - 1, String.valueOf(resultNum));
                    i--;

                }
            }


        System.out.print("结果: ");
        return Long.parseLong(list.get(0));
    }

    /**
     * 遍历集合输出
     * @param list
     */
    public static void ergodic(List<String> list){
        for (String ele : list) {
            System.out.print(ele);
        }
        System.out.println();
    }

    /**
     * 判断输入的表达式是否有堆叠的运算符
     * @param expression
     * @throws ExpressionException
     */
    public void expressionCheck(String expression) throws ExpressionException{
        for (int i = 0; i < expression.length()-1; i++) {
            if ((expression.charAt(i) == '+' || expression.charAt(i) == '-' ||expression.charAt(i) == '/' ||
                    expression.charAt(i) == '*') && (expression.charAt(i+1) == '+' ||
                    expression.charAt(i+1) == '-' ||expression.charAt(i+1) == '/' ||
                    expression.charAt(i+1) == '*')){
                System.out.println("式子错误");
                throw new ExpressionException("运算符堆叠");
            }
        }
            System.out.print("原式为: ");
            System.out.println(expression);
    }


}
