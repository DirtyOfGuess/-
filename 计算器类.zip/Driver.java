import java.util.Scanner;

public class Driver {
    public static void main(String[] args) {
        //输入式子
        Scanner scan = new Scanner(System.in);
        System.out.print("请输入一个无括号的运算式: ");
        String expression = scan.next();
        long result;

        try {
            //运算式子
            Calculator calculator = new Calculator();
            result = calculator.Calculate(expression);
            System.out.println(result);
        } catch (ExpressionException e){
            System.out.println("计算失败，运算符堆叠");
            e.printStackTrace();
            System.exit(0);
        }catch (ResultException e){
            System.out.println("计算失败，计算结果溢出");
            e.printStackTrace();
            System.exit(0);
        }

    }
}
