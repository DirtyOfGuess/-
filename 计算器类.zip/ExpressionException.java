public class ExpressionException extends Exception{
    public ExpressionException() {
    }
    public ExpressionException(String message) {
        super(message);
    }
}
