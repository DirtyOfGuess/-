public class ResultException extends Exception{
    public ResultException() {
    }

    public ResultException(String message) {
        super(message);
    }
}
